
    /* Counter - CountTo */
	var a = 0;
	$(window).scroll(function() {
		if ($('#counter').length) { // checking if CountTo section exists in the page, if not it will not run the script and avoid errors
			var oTop = $('#counter').offset().top - window.innerHeight;
			if (a == 0 && $(window).scrollTop() > oTop) {
			$('.counter-value').each(function() {
				var $this = $(this),
				countTo = $this.attr('data-count');
				$({
				countNum: $this.text()
				}).animate({
					countNum: countTo
				},
				{
					duration: 2000,
					easing: 'swing',
					step: function() {
					$this.text(Math.floor(this.countNum));
					},
					complete: function() {
					$this.text(this.countNum);
					//alert('finished');
					}
				});
			});
			a = 1;
			}
		}
    });


	// for AOS library
	AOS.init({
            // Settings that can be overridden on per-element basis, by data-aos-* attributes:
            //offset: 120, // offset (in px) from the original trigger point
            //delay: 0, // values from 0 to 3000, with step 50ms
            //duration: 800, // values from 0 to 3000, with step 50ms
            easing: 'ease', // default easing for AOS animations
            once: false, // whether animation should happen only once - while scrolling down
            mirror: false, // whether elements should animate out while scrolling past them
            anchorPlacement: 'top-bottom', // defines which position of the element regarding to window should trigger the animation
        });


	// for make the navbar sticky when scrolling
	$(window).scroll(function(){
            if ($(window).scrollTop()){
                $("nav").addClass("Add-Shadow");
                $(".container").removeClass("Add-Border");
            }
            else{
                $("nav").removeClass("Add-Shadow");
                $(".container").addClass("Add-Border");
            }
        })



  // Testimonials slider

new Swiper('.testimonials-slider', {
	speed: 600,
	loop: true,
	autoplay: {
	delay: 5000,
	disableOnInteraction: false
	},
	slidesPerView: 'auto',
	pagination: {
	el: '.swiper-pagination',
	type: 'bullets',
	clickable: true
	},
	breakpoints: {
	320: {
	slidesPerView: 1,
	spaceBetween: 40
	},

	1200: {
	slidesPerView: 3,
	}
	}
});

// preloader
const preloader = document.querySelector('#dots-container');
    if (preloader) {
        window.addEventListener('load', () => {
            setTimeout(function () {
            preloader.remove();
            }, 1700);
        });
    }

